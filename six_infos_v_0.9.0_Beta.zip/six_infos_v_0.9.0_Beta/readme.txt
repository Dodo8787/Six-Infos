SOUS Ubuntu 22.04 (Linux):

1=>Entrer ce qui suit dans un terminal: sudo apt install python3-pip python3-tk python3-matplotlib python3-pil python3-pil.imagetk && pip install matplotlib ttkthemes screeninfo Pillow psutil
2=>Executez le fichier "start_in_shell_Linux.sh": soit rendre executable le fichier et l executer comme un programme, soit dans une console ouverte là ou se trouve le fichier "start_in_shell_Linux.sh" et entrer: ./start_in_shell_Linux.sh


In english:

1=>Copy and paste this in a terminal: sudo apt install python3-pip python3-tk python3-matplotlib python3-pil python3-pil.imagetk && pip install matplotlib ttkthemes screeninfo Pillow psutil

2=>Execute the file "start_in_shell_Linux.sh"

If you found a bug, I am glade you post the file "log_error.txt" (or his content) on GitHub for I try to correct it!
Thanks! 

Enjoy!!!
____________________________________


SOUS Ubuntu 23.04 (Linux):

1=>Entrer ce qui suit dans un terminal: sudo apt install python3-tk python3-matplotlib python3-pil python3-pil.imagetk python3-ttkthemes python3-screeninfo python3-Pillow python3-psutil
2=>Executez le fichier "start_in_shell_Linux.sh" (meme procedure que pour ubuntu 22.04)

In english:

1=>Copy and paste this in a terminal: sudo apt install python3-tk python3-matplotlib python3-pil python3-pil.imagetk python3-ttkthemes python3-screeninfo python3-Pillow python3-psutil

2=>Execute the file "start_in_shell_Linux.sh"

If you found a bug, I am glade you post the file "log_error.txt" (or his content) on GitHub for I try to correct it!
Thanks!

Enjoy!!!
_________________________________________________________________


SOUS WINDOWS 11:

1=>Installer python et BIEN cocher la case "Add python.exe to Path" lors de l'installation.
2=>Mettre a jour pip (entrer la ligne suivante dans une console: python.exe -m pip install --upgrade pip)
3=>Installer tk (entrer la ligne suivante dans une console: pip install tk)
4=>Installer ttkthemes (entrer la ligne suivante dans une console: pip install ttkthemes)
5=>Installer psutil (entrer la ligne suivante dans une console: pip install psutil)
6=>Install screeninfo (entrer la ligne suiante dans une console: pip install screeninfo)
7=>Installer matplotlib (entrer la ligne suivante dans une console: pip install matplotlib)

8=> Télécharger et installer microsoft visual c++ 2015

Les étapes 3, 4, 5, 5 et 7 peuvent etre regroupées en une seule ligne dans la console: pip install tk ttkthemes psutil screeninfo matplotlib

9=>lancer le script "start_in_shell_Windows.bat"

***ASTUCE pour avoir un beau design: regler le zoom de l'application sur 90 (parametres de l'appli puis reglages puis application)***
Enjoy !!!

