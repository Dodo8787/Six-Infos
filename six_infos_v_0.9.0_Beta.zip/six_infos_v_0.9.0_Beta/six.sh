#!/bin/bash

xterm -e 'python3 /media/dodo/ssd1ToInterne/Dropbox/Six-Infos/Old_Six-Infos/main.py;read'
